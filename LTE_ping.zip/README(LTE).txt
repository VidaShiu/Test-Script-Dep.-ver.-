Test Item: 3.01.1/3.01.2/3.01.3/3.01.4/3.01.5 Power cycle
Test Purpose: Verify the external connectivity quality and stability of the LTE module.
Test Environment: Windows OS
Script/Tool Name: 
LTE_ping(TestVer).bat
	Pre-condition:
1. Open Command Prompt and execute the following command to retrieve the cellular interface name. (e.g.: Cellular 3)
2. Open the batch file LTE_ping(TestVer).bat using Notepad or any text editor.
3. Locate the placeholder cellular name (e.g., "Cellular 3") in the script and replace it.
4. Save the changes by pressing Ctrl + S.
 
5. Open Task Scheduler and settings as follows:
General:
Name: LTE_Ping
Run only user is looed on =Enable
Run with highest privilegs=Enable 
Triggers>New:
Begin the task: At log on
Settings: One time
Actions>New:
Action: Start a program
Settings>Browse: add Script
Start in: Script’s directory location
Test Methods:
Step 1: Configure the power cycle test. The script will log each cycle automatically.
Step 2: After the test is completed, retrieve the log file from the same directory.